import * as firebase from "firebase/app";
import "firebase/auth";
import "firebase/database";

// Essa configuração é aquela que você obteve no quarto passo
// A mostrada a seguir é um exemplo. Não copie. Use a sua.
const firebaseConfig = {
  apiKey: "AIzaSyArZ7V1Zj_H8T0ttItQvOJUs2Lxxxxxxxx",
  authDomain: "fir-login-16872.firebaseapp.com",
  databaseURL: "https://fir-login-16872.firebaseio.com",
  projectId: "fir-login-16872",
  storageBucket: "fir-login-16872.appspot.com",
  messagingSenderId: "212660424551",
  appId: "1:212850424551:web:c1c39910a3fd58a2acc042",
};
firebase.initializeApp(firebaseConfig);

export default firebase;